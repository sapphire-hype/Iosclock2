package com.example.iosclock.ui

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

/** Process-wide stopwatch state so it keeps running while you switch tabs. */
object StopwatchEngine {
    var running by mutableStateOf(false)
    private var startMark = 0L
    private var accumulated = 0L
    /** Cumulative elapsed time at each lap press, oldest first. */
    val laps = mutableStateListOf<Long>()

    fun elapsed(): Long = accumulated + if (running) SystemClock.elapsedRealtime() - startMark else 0L

    fun start() {
        startMark = SystemClock.elapsedRealtime()
        running = true
    }

    fun stop() {
        accumulated = elapsed()
        running = false
    }

    fun lap() {
        laps.add(elapsed())
    }

    fun reset() {
        running = false
        accumulated = 0L
        laps.clear()
    }

    val lapStart: Long get() = laps.lastOrNull() ?: 0L
}

fun formatStopwatch(ms: Long): String {
    val cs = (ms / 10) % 100
    val s = (ms / 1000) % 60
    val m = (ms / 60000) % 60
    val h = ms / 3600000
    return if (h > 0) "%d:%02d:%02d.%02d".format(h, m, s, cs) else "%02d:%02d.%02d".format(m, s, cs)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun StopwatchScreen() {
    var elapsed by remember { mutableLongStateOf(StopwatchEngine.elapsed()) }
    LaunchedEffect(StopwatchEngine.running) {
        elapsed = StopwatchEngine.elapsed()
        while (StopwatchEngine.running) {
            withFrameMillis { }
            elapsed = StopwatchEngine.elapsed()
        }
    }
    val running = StopwatchEngine.running
    val pager = rememberPagerState(pageCount = { 2 })

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxWidth().height(340.dp)) { page ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (page == 0) {
                    Text(
                        formatStopwatch(elapsed),
                        color = Color.White,
                        style = TextStyle(fontSize = 78.sp, fontWeight = FontWeight.Thin, fontFeatureSettings = "tnum"),
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AnalogStopwatch(elapsed, Modifier.size(260.dp))
                        Text(
                            formatStopwatch(elapsed),
                            color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light,
                            style = TextStyle(fontFeatureSettings = "tnum"),
                            modifier = Modifier.padding(top = 8.dp),
                        )
                    }
                }
            }
        }
        Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(2) { i ->
                Box(
                    Modifier.size(7.dp)
                        .background(if (pager.currentPage == i) Color.White else IosDarkGray, CircleShape)
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            val canReset = !running && elapsed > 0
            CircleButton(
                label = if (canReset) "Reset" else "Lap",
                bg = IosDarkGray, fg = Color.White,
                enabled = running || canReset,
            ) {
                if (running) StopwatchEngine.lap() else StopwatchEngine.reset()
                elapsed = StopwatchEngine.elapsed()
            }
            if (running) {
                CircleButton("Stop", IosRedBg, IosRed) { StopwatchEngine.stop() }
            } else {
                CircleButton("Start", IosGreenBg, IosGreen) { StopwatchEngine.start() }
            }
        }
        HorizontalDivider(color = IosSep, modifier = Modifier.padding(top = 8.dp))

        val laps = StopwatchEngine.laps
        val lapTimes = laps.mapIndexed { i, t -> t - (if (i == 0) 0L else laps[i - 1]) }
        val best = if (lapTimes.size >= 2) lapTimes.min() else null
        val worst = if (lapTimes.size >= 2) lapTimes.max() else null
        // Rows: current lap on top (only once at least one lap exists or timer started), then laps newest first.
        val showCurrent = running || elapsed > 0
        LazyColumn(Modifier.fillMaxWidth()) {
            if (showCurrent) {
                item {
                    LapRow("Lap ${laps.size + 1}", formatStopwatch(elapsed - StopwatchEngine.lapStart), Color.White)
                }
            }
            itemsIndexed(lapTimes.reversed()) { idx, t ->
                val number = lapTimes.size - idx
                val color = when (t) {
                    best -> IosGreen
                    worst -> IosRed
                    else -> Color.White
                }
                LapRow("Lap $number", formatStopwatch(t), color)
            }
        }
    }
}

@Composable
private fun LapRow(label: String, time: String, color: Color) {
    Column {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(label, color = color, fontSize = 17.sp)
            Text(time, color = color, fontSize = 17.sp, style = TextStyle(fontFeatureSettings = "tnum"))
        }
        HorizontalDivider(color = IosSep, modifier = Modifier.padding(horizontal = 24.dp))
    }
}

@Composable
private fun AnalogStopwatch(elapsed: Long, modifier: Modifier = Modifier) {
    val measurer = rememberTextMeasurer()
    Canvas(modifier) {
        val c = center
        val radius = size.minDimension / 2
        // Ticks: 240 small ticks (quarter-second), 60 longer second ticks.
        for (i in 0 until 240) {
            val a = Math.toRadians(i * 1.5 - 90)
            val major = i % 4 == 0
            val len = if (major) 12f else 6f
            val w = if (major) 3f else 1.5f
            val outer = Offset(c.x + (radius * cos(a)).toFloat(), c.y + (radius * sin(a)).toFloat())
            val inner = Offset(
                c.x + ((radius - len) * cos(a)).toFloat(),
                c.y + ((radius - len) * sin(a)).toFloat(),
            )
            drawLine(if (major) Color.White else IosGray, inner, outer, strokeWidth = w)
        }
        // Numbers every 5 seconds.
        for (n in 1..12) {
            val label = (n * 5).toString()
            val a = Math.toRadians(n * 30.0 - 90)
            val layout = measurer.measure(label, TextStyle(color = Color.White, fontSize = 18.sp))
            val r = radius - 34f
            drawText(
                layout,
                topLeft = Offset(
                    c.x + (r * cos(a)).toFloat() - layout.size.width / 2f,
                    c.y + (r * sin(a)).toFloat() - layout.size.height / 2f,
                ),
            )
        }
        // Second hand.
        val sec = (elapsed % 60000) / 60000.0
        val a = Math.toRadians(sec * 360 - 90)
        val tail = 24f
        drawLine(
            IosOrange,
            Offset(c.x - (tail * cos(a)).toFloat(), c.y - (tail * sin(a)).toFloat()),
            Offset(c.x + ((radius - 8f) * cos(a)).toFloat(), c.y + ((radius - 8f) * sin(a)).toFloat()),
            strokeWidth = 3f, cap = StrokeCap.Round,
        )
        drawCircle(IosOrange, radius = 7f, center = c)
        drawCircle(Color.Black, radius = 2.5f, center = c)
    }
}
