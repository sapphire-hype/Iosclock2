package com.example.iosclock.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.iosclock.alarm.AlarmItem
import com.example.iosclock.alarm.AlarmScheduler
import com.example.iosclock.alarm.AlarmStore
import java.util.Calendar

private val dayNames = mapOf(
    Calendar.SUNDAY to "Sun", Calendar.MONDAY to "Mon", Calendar.TUESDAY to "Tue",
    Calendar.WEDNESDAY to "Wed", Calendar.THURSDAY to "Thu", Calendar.FRIDAY to "Fri",
    Calendar.SATURDAY to "Sat",
)
private val dayOrder = listOf(
    Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
    Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY,
)
private val dayLetters = listOf("S", "M", "T", "W", "T", "F", "S")

private fun daysText(days: Set<Int>): String = when {
    days.isEmpty() -> ""
    days.size == 7 -> "Every day"
    else -> dayOrder.filter { it in days }.joinToString(" ") { dayNames[it]!! }
}

private fun hour12(h: Int) = if (h % 12 == 0) 12 else h % 12

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmScreen() {
    val ctx = LocalContext.current
    var alarms by remember { mutableStateOf(AlarmStore.load(ctx)) }
    var editMode by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf<AlarmItem?>(null) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { alarms = AlarmStore.load(ctx) }

    fun commit(list: List<AlarmItem>) {
        alarms = list
        AlarmStore.save(ctx, list)
    }

    fun upsert(a: AlarmItem) {
        val exists = alarms.any { it.id == a.id }
        commit(if (exists) alarms.map { if (it.id == a.id) a else it } else alarms + a)
        AlarmScheduler.schedule(ctx, a)
    }

    fun delete(a: AlarmItem) {
        AlarmScheduler.cancel(ctx, a.id)
        commit(alarms.filter { it.id != a.id })
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "Alarm",
            left = { OrangeTextButton(if (editMode) "Done" else "Edit") { editMode = !editMode } },
            right = {
                IconButton(onClick = { sheet = AlarmItem(0, 7, 0) }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add alarm", tint = IosOrange)
                }
            },
        )
        HorizontalDivider(color = IosSep, modifier = Modifier.padding(top = 8.dp))
        if (alarms.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No Alarms", color = IosGray, fontSize = 20.sp)
            }
        }
        LazyColumn(Modifier.fillMaxWidth()) {
            items(alarms.sortedWith(compareBy({ it.hour }, { it.minute })), key = { it.id }) { a ->
                val dim = if (a.enabled) Color.White else IosGray
                Row(
                    Modifier.fillMaxWidth().clickable { sheet = a }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (editMode) {
                        Box(
                            Modifier.size(24.dp).background(IosRed, CircleShape).clickable { delete(a) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Filled.Remove, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                        Box(Modifier.size(12.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                "${hour12(a.hour)}:${"%02d".format(a.minute)}",
                                color = dim,
                                style = TextStyle(fontSize = 56.sp, fontWeight = FontWeight.Light, fontFeatureSettings = "tnum"),
                            )
                            Text(
                                " " + if (a.hour < 12) "AM" else "PM",
                                color = dim, fontSize = 24.sp,
                                modifier = Modifier.padding(bottom = 10.dp),
                            )
                        }
                        val sub = listOf(a.label.ifBlank { "Alarm" }, daysText(a.days)).filter { it.isNotEmpty() }
                            .joinToString(", ")
                        Text(sub, color = dim, fontSize = 15.sp)
                    }
                    if (!editMode) {
                        Switch(
                            checked = a.enabled,
                            onCheckedChange = { upsert(a.copy(enabled = it)) },
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = IosGreen,
                                checkedThumbColor = Color.White,
                                uncheckedTrackColor = IosDarkGray,
                                uncheckedThumbColor = Color.White,
                                uncheckedBorderColor = IosDarkGray,
                                checkedBorderColor = IosGreen,
                            ),
                        )
                    }
                }
                HorizontalDivider(color = IosSep)
            }
        }
    }

    sheet?.let { target ->
        ModalBottomSheet(
            onDismissRequest = { sheet = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = IosCard,
        ) {
            AlarmEditor(
                initial = target,
                isNew = target.id == 0,
                onCancel = { sheet = null },
                onSave = { saved ->
                    val withId = if (saved.id == 0) saved.copy(id = AlarmStore.newId()) else saved
                    upsert(withId.copy(enabled = true))
                    sheet = null
                },
                onDelete = { delete(target); sheet = null },
            )
        }
    }
}

@Composable
private fun AlarmEditor(
    initial: AlarmItem,
    isNew: Boolean,
    onCancel: () -> Unit,
    onSave: (AlarmItem) -> Unit,
    onDelete: () -> Unit,
) {
    var h12 by remember { mutableIntStateOf(hour12(initial.hour)) }
    var minute by remember { mutableIntStateOf(initial.minute) }
    var pm by remember { mutableIntStateOf(if (initial.hour >= 12) 1 else 0) }
    var days by remember { mutableStateOf(initial.days) }
    var label by remember { mutableStateOf(initial.label) }

    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            OrangeTextButton("Cancel", onCancel)
            Text(if (isNew) "Add Alarm" else "Edit Alarm", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            OrangeTextButton("Save") {
                val hour = (h12 % 12) + if (pm == 1) 12 else 0
                onSave(initial.copy(hour = hour, minute = minute, label = label, days = days))
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            WheelPicker((1..12), h12, { h12 = it }, Modifier.weight(1f))
            WheelPicker((0..59), minute, { minute = it }, Modifier.weight(1f), format = { "%02d".format(it) })
            WheelPicker((0..1), pm, { pm = it }, Modifier.weight(1f), format = { if (it == 0) "AM" else "PM" })
        }
        Text("Repeat", color = IosGray, fontSize = 14.sp, modifier = Modifier.padding(vertical = 4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            dayOrder.forEachIndexed { i, d ->
                val on = d in days
                Box(
                    Modifier.size(40.dp).background(if (on) IosOrange else IosDarkGray, CircleShape)
                        .clickable { days = if (on) days - d else days + d },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(dayLetters[i], color = if (on) Color.Black else Color.White, fontSize = 15.sp)
                }
            }
        }
        TextField(
            value = label,
            onValueChange = { label = it },
            label = { Text("Label", color = IosGray) },
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = IosDarkGray,
                unfocusedContainerColor = IosDarkGray,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
            ),
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
        )
        if (!isNew) {
            Text(
                "Delete Alarm",
                color = IosRed, fontSize = 17.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).clickable(onClick = onDelete).padding(top = 16.dp),
            )
        }
    }
}
