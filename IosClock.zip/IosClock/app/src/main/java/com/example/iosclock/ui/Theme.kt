package com.example.iosclock.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val IosOrange = Color(0xFFFF9F0A)
val IosBg = Color.Black
val IosCard = Color(0xFF1C1C1E)
val IosGray = Color(0xFF8E8E93)
val IosSep = Color(0xFF38383A)
val IosGreen = Color(0xFF30D158)
val IosGreenBg = Color(0xFF0B3D1A)
val IosRed = Color(0xFFFF453A)
val IosRedBg = Color(0xFF3D0B0B)
val IosDarkGray = Color(0xFF333333)
val IosWheelHighlight = Color(0x33787880)

@Composable
fun ClockTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = IosOrange,
            background = IosBg,
            surface = IosBg,
            surfaceVariant = IosCard,
            onSurface = Color.White,
            onBackground = Color.White,
        ),
        content = content,
    )
}
